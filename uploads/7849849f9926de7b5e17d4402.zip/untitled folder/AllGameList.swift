//
//  AllGameList.swift
//  eFriend
//
//  Created by Kamalnath Gunda on 23/04/24.
//

import UIKit
enum GameListEnum: String {
    case YES_NO_GAME
    case SPIN_WHEEL
    case TEEN_PATTI
    case CAR_RACE
    case LUCKY_SEVEN
}
class AllGameList: UIViewController {
    
    @IBOutlet weak var activeGameList: UITableView!
    
    var noDatalabelObj = UILabel()
    var racingGamePerSecModel:RacingGamePerSecModel?
    var walletbalance = Double()
    var activeGameArray = [JSON]()
    let refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.setStatusBar(backgroundColor: hexStringToUIColor(hex: AppColor.HexThemColor))
        
        self.getuserMetaForAll(view: self.view, istoShowLoader: true) {
            if let activegameArray = UserMetadataSinglton.shared.jsonDic["activeGames"]?.arrayValue {
                self.activeGameArray = activegameArray
            }else{
                self.activeGameArray = []
            }
            self.getLanguagesArrayList()
            self.activeGameList.reloadData()
            if self.activeGameArray.count == 0{
                self.notDataLabel(viewObj: self.view, count: self.activeGameArray.count, label: self.noDatalabelObj)
            }else{
                self.noDatalabelObj.isHidden = true
            }
        }
        refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        navigationSetup()
        self.activeGameList.refreshControl = refreshControl
        NotificationCenter.default.addObserver(self, selector: #selector(updateWallet(_:)), name: NSNotification.Name("Update_Wallet"), object: nil)
    }
    @objc func updateWallet(_ notification: Notification) {
        let gamewallet = self.checkgameWallet()
        var originalImage = UIImage()
        if gamewallet == false {
            self.getWalletBalanceGloble { totalBalance in
                self.walletbalance = totalBalance
                self.setupNavRightBarButton()
            }
        }else{
            self.getGameWalletBalance { totalBalance in
                self.walletbalance = totalBalance
                self.setupNavRightBarButton()
            }
        }
    }
    
    func setupNavRightBarButton() {
        let walletButton = self.setWalletAmountInNavigation()
        self.navigationItem.rightBarButtonItems = [walletButton]
    }
    
    func setWalletAmountInNavigation() -> UIBarButtonItem {
        var totalRechargeAmount = String()
        
        let gamewallet = self.checkgameWallet()
        var originalImage = UIImage()
        if gamewallet == false {
            originalImage = UIImage(systemName: "phone.fill")!.withTintColor(.white)
            totalRechargeAmount = "\(self.walletbalance)"
        }else{
            originalImage = UIImage(named: "GameIconNavigation")!.withTintColor(.white)
            totalRechargeAmount = "\(self.walletbalance)"
        }
        let walletText = " \(kRupeeSymbolGame)\(formatDoubleForRate(self.walletbalance)) "
        let walletButton = UIButton(type: .custom)
        
        // Configure wallet icon
        walletButton.setImage(originalImage, for: .normal)
        walletButton.imageView?.contentMode = .scaleAspectFit
        
        // Control image size
        let iconSize = CGSize(width: 10, height: 10)
        walletButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 10) // Adjust spacing between image and text
        
        // Configure wallet text
        walletButton.setTitle(walletText, for: .normal)
        walletButton.setTitleColor(.white, for: .normal)
        walletButton.titleLabel?.font = UIFont.systemFont(ofSize: 14.0, weight: .light) // Set font weight to .light
        walletButton.titleLabel?.adjustsFontSizeToFitWidth = true
        
        // Calculate width for the button
        let textWidth = (walletText as NSString).size(withAttributes: [.font: UIFont.systemFont(ofSize: 14.0, weight: .light)]).width
        let buttonWidth = iconSize.width + textWidth + 15 // Adjust spacing and padding
        
        walletButton.frame = CGRect(x: 5, y: 0, width: buttonWidth, height: 30) // Increase overall height
        
        // Add border and corner radius
        walletButton.layer.borderWidth = 1
        walletButton.layer.borderColor = UIColor.white.cgColor
        walletButton.layer.cornerRadius = 8
        walletButton.layer.masksToBounds = true
        
        // Add action
        walletButton.addTarget(self, action: #selector(btnRechargePressedNav(sender:)), for: .touchUpInside)
        
        // Create custom bar button item
        let walletBarButtonItem = UIBarButtonItem(customView: walletButton)
        
        return walletBarButtonItem
    }
    @objc func btnRechargePressedNav(sender: UIButton) {
        let controller = NewAddMoneyVC()
        let gamewallet = self.checkgameWallet()
        controller.hidesBottomBarWhenPushed = true
        _ = UIImage()
        if gamewallet == false {
            controller.amountobj = self.getUserWalletBalance()
        }else{
            controller.isGameTalkTime = true
            controller.amountobj = self.getUserGameBalance()
        }
        self.navigationController?.pushViewController(controller, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        showbottomBar()
        self.carRaceGameMetaData(view: self.view) {
            
        }
        let gamewallet = self.checkgameWallet()
        var originalImage = UIImage()
        if gamewallet == false {
            self.getWalletBalanceGloble { totalBalance in
                self.walletbalance = totalBalance
                self.setupNavRightBarButton()
            }
        }else{
            self.getGameWalletBalance { totalBalance in
                self.walletbalance = totalBalance
                self.setupNavRightBarButton()
            }
        }
    }
    func navigationSetup()  {
        let titalText =  self.barUIlableText(labelText: "Play and earn")
        self.navigationItem.leftBarButtonItems = [UIBarButtonItem.init(customView: titalText)]
    }
    @objc func refreshData(_ sender: Any) {
        self.refreshList()
    }
    func refreshList()  {
        refreshControl.endRefreshing()
        self.activeGameArray.removeAll()
        self.activeGameList.reloadData()
        self.getuserMetaForAll(view: self.view, istoShowLoader: true) {
            if let activegameArray = UserMetadataSinglton.shared.jsonDic["activeGames"]?.arrayValue {
                self.activeGameArray = activegameArray
            }else{
                self.activeGameArray = []
            }
            self.activeGameList.reloadData()
            if self.activeGameArray.count == 0{
                self.notDataLabel(viewObj: self.view, count: self.activeGameArray.count, label: self.noDatalabelObj)
            }else{
                self.noDatalabelObj.isHidden = true
            }
        }
    }
}
